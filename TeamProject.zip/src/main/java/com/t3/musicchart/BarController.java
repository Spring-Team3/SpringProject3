package com.t3.musicchart;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BarController {

	@RequestMapping(value="/bar")
	public String bar() {
		
		
		
		return "chartFolder/bar";
	}
	
}
